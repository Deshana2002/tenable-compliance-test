import logging

from ..tenable_helper import TenableIO


def main(timestamp: int) -> object:
    logging.info('using pyTenable client to create new compliance export job')
    tio = TenableIO()
    logging.info(
        'requesting a new Compliance Export Job from Tenable')
    # limiting chunk size to contain 100 compliance details. For some bigger
    # containers, each chunk is reported to be some hundreds of MBs resulting
    # into azure function crash due to OOM errors.
    job_id = tio.exports.compliance(use_iterator=False, num_findings=100)

    logging.info('received a response from Compliance Export Job request. job_id = {}'.format(job_id))
    return job_id
